<footer id="footer">
        <div class="container">
            <div class="col-md-4 ">
            <h3>SUPPORT</h3>
            <!-- <img src="assets/front_end/images/support/bank.png" alt="bank" style="width: 100%"> -->
            </div>
            <div class="col-md-5 operasi">
            <h3>ABOUT</h3>
            <ul class="alamat">
                <li><i class="glyphicon glyphicon-map-marker"></i><b> ADECREATIVE21</b><span>Jalan Karet Gang Karet Indah No.14 Pontianak Barat Pontianak, Kalimantan Barat, Indonesia - 78113</span></li>
                <li><i class="glyphicon glyphicon-envelope"></i><a href="mailto:adetiyaputra45@gmail.com"> adetiyaputra45@gmail.com</a></li>
                
            </ul>
            </div>
            <div class="col-md-3 ">
            <h3>PROFIL</h3>
            <ul class="infoo">
                <li><i class="fa fa-arrow-right"></i><a href=""> About Us</a></li>
                <li><i class="fa fa-arrow-right"></i><a href=""> Contact Us</a></li>
            </ul>
        </div>
        <div class="clearfix"> </div>
        </div>
    </footer>
</body>
</html>

<script src="<?php echo e(url('css/bootstrap/js/bootstrap.min.js')); ?>"></script>
<script src="<?php echo e(url('js/bootstrap.min.js')); ?>"></script>