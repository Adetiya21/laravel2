<?php echo $__env->make('inc.header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

    <div class="container">
        <h1>Detail data "<?php echo e($articles->title); ?>"</h1>
        <table class="table table-hover">
            <tbody>
                <tr><td>ID</td>
                    <td><?php echo e($articles->id); ?></td></tr>
                <tr><td>Title</td>
                    <td><?php echo e($articles->title); ?></td></tr>
                <tr><td>Description</td>
                    <td><?php echo e($articles->description); ?></td></tr>
            </tbody>
        </table>
        <a href="<?php echo e(url('/')); ?>" class="btn btn-primary">Back</a>
    </div>
    <br>

<?php echo $__env->make('inc.footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>