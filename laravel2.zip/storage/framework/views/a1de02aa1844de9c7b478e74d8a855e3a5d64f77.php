<?php echo $__env->make('inc.header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

    <div class="container">
        <h1>Books List</h1>
        <?php if(session('info')): ?>
            <div class="col-md-6 alert alert-success">
                <?php echo e(session('info')); ?>

            </div>    
        <?php endif; ?>
        <div class="col-md-12 table-responsive">
            <table class="table table-hover">
                <thead>
                    <tr>
                        <th>No</th>
                        <th>Title</th>
                        <th>Description</th>
                        <th>Action</th>
                    </tr>
                </thead>
                <tbody>
                    
                    <?php 
                        $no=1;
                     ?>
                    <?php $__currentLoopData = $articles->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $article): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        
                    <tr>
                        <td><?php echo e($no++); ?></td>
                        <td><?php echo e($article->title); ?></td>
                        <td><?php echo e($article->description); ?></td>
                        <td>
                            <a href='<?php echo e(url("/detail/{$article->id}")); ?>' class="btn btn-primary">View</a>
                            <a href='<?php echo e(url("/edit/{$article->id}")); ?>' class="btn btn-warning">Edit</a>
                            <a href='<?php echo e(url("/delete/{$article->id}")); ?>' class="btn btn-danger">Delete</a>
                        </td>
                    </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    
                </tbody>
            </table>
        </div>
        <?php echo e($articles->links()); ?>

    </div>

    <script type="text/javascript">
        $(document).ready(function() {
            $('.home').addClass('active');
        });
    </script>

<?php echo $__env->make('inc.footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>